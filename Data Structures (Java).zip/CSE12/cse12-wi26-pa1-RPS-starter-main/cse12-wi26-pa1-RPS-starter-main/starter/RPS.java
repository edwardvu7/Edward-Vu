import java.util.Scanner;

public class RPS extends RPSAbstract {
    // Messages for the game.
    protected static final String GAME_NOT_IMPLEMENTED =
            "Game not yet implemented.";
    /**
     * Construct a new instance of RPS with the given possible moves.
     *
     * @param moves all possible moves in the game.
     */
    public RPS(String[] moves) {
        this.possibleMoves = moves;
        this.playerMoves = new String[MAX_GAMES];
        this.cpuMoves = new String[MAX_GAMES];
        this.recentPlayerMoves = new String[MAX_RECENT_WINS];
        this.recentCPUMoves = new String[MAX_RECENT_WINS];
    }

    public static void main(String[] args) {
        // If command line args are provided use those as the possible moves
        String[] moves = new String[args.length];
        if (args.length >= MIN_POSSIBLE_MOVES) {
            System.arraycopy(args, 0, moves, 0, args.length);
        } else {
            moves = RPS.DEFAULT_MOVES;
        }
        // Create new game and scanner
        RPS game = new RPS(moves);
        Scanner in = new Scanner(System.in);

        // While user does not input "q", play game
        System.out.println(PROMPT_MOVE);
        String input = in.nextLine().toLowerCase();
        while(!(input.equals(QUIT))){
            String cpuMove = game.genCPUMove();
            if(!(game.isValidMove(input))){
                System.out.println(INVALID_INPUT);
            }
            else{
                game.playRPS(input, cpuMove);   
            }
            System.out.println(PROMPT_MOVE);
            input = in.nextLine().toLowerCase();
        }
        game.displayStats();
        in.close();
    }

    @Override
    public int determineWinner(String playerMove, String cpuMove) {
        int indexPlayer = -1;
        int indexCPU = -1;
        if(playerMove == null || cpuMove == null){
            return INVALID_INPUT_OUTCOME;
        }
        for(int i = 0; i < possibleMoves.length; ++i){
            if(playerMove.equals(possibleMoves[i])){
                indexPlayer = i;
                break;
            }
        }
        if(indexPlayer == -1){
            return INVALID_INPUT_OUTCOME;
        }
        for(int i = 0; i < possibleMoves.length; ++i){
            if(cpuMove.equals(possibleMoves[i])){
                indexCPU = i;
                break;
            }
        }
        if(indexCPU == -1){
            return INVALID_INPUT_OUTCOME;
        }
        if(indexPlayer == 0){
            if(indexCPU == possibleMoves.length - 1){
                return PLAYER_WIN_OUTCOME;
            }
        }
        if(indexCPU == 0){
            if(indexPlayer == possibleMoves.length - 1){
                return CPU_WIN_OUTCOME;
            }
        }
        if(indexCPU == indexPlayer + 1){
            return CPU_WIN_OUTCOME;
        }
        else if(indexCPU == indexPlayer - 1){
            return PLAYER_WIN_OUTCOME;
        }
        else{
            return TIE_OUTCOME;
        }
    }
}
