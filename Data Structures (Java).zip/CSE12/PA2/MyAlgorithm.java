/*
 * Name: Edward Vu
 *
 * Contains the MyAlgorithm class which holds the algorithm to test the ArrayList
 */

/**
 * A concrete class that implements a static method utilizing MyArrayList
 */
public class MyAlgorithm {
    private static final String INVALIDOFF = "Invalid offset";
    private static final String INVALIDARR = "Invalid array";

    /**
     * Takes a MyArrayList of Integers and moves elements, in the
     * range of [val * - offset, val + offset], to the end.
     * This is done in-place.
     * @param nums list of Integers
     * @param val center of range
     * @param offset width of range
     * @return shifted MyArrayList
     */
    public static MyArrayList<Integer> shiftToEnd(MyArrayList<Integer> nums, 
        int val, int offset) {
        if(offset < 0){
            throw new IllegalArgumentException(INVALIDOFF);
        }
        if(nums == null || nums.getCapacity() == 0){
            throw new NullPointerException(INVALIDARR);
        }
        int end = nums.size();
        for(int i = 0; i < end; ++i){
            int cur = nums.get(i);
            if(cur <= val + offset && cur >= val - offset){
                nums.remove(i);
                nums.append(cur);
                end--;
                i--;
            }
        }
        return nums;
    }
}