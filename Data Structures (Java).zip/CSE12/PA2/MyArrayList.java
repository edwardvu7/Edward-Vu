/*
 * Name: Edward Vu
 *
 * Contains the MyArrayList class which acts as an ArrayList
 */


/**
 * class containing methods used in an Arraylist
 */
public class MyArrayList<E> implements MyList<E>{
    Object[] data;
    int size;
    private static final int DEFAULT = 5;
    private static final String invalidCap = "Invalid Capacity";
    private static final String invalidInd = "Invalid Index";
    private static final int DOUBLE = 2;

    /**
     * Constructor that is default for no parameters
     */
    public MyArrayList(){
        size = 0;
        data = new Object[DEFAULT];

    }

    /**
     * constructor for parameters of initialCapacity
     * @param initialCapacity the initial capacity to start
     */
    public MyArrayList(int initialCapacity){
        if(initialCapacity < 0){
            throw new IllegalArgumentException(invalidCap);
        }
        data = new Object[initialCapacity];
        size = 0;
    }

    /**
     * constructor that takes in an array
     * @param arr initial array to start with
     */
    public MyArrayList(E[] arr){
        if(arr == null){
            size = 0;
            data = new Object[DEFAULT];
        }
        else{
            data = new Object[arr.length];
            for(int i = 0; i < arr.length; ++i){
                data[i] = arr[i];
            }
            size = arr.length;
        }
    }

    /**
     * method that expands the capacity of the array
     * @param requiredCapacity the capacity needed in the array
     */
    public void expandCapacity(int requiredCapacity){
        if(requiredCapacity < data.length){
            throw new IllegalArgumentException(invalidCap);
        }
        if(data.length == 0){
            if(requiredCapacity > DEFAULT){
                data = new Object[requiredCapacity];
            }
            else{
                data = new Object[DEFAULT];
            }
            return;
        }
        if((data.length * DOUBLE) < requiredCapacity){
            Object[] temp = new Object[requiredCapacity];
            for(int i = 0; i < size; ++i){
                temp[i] = data[i];
            }
            data = temp;
        }
        else{
            Object[] temp = new Object[data.length * DOUBLE];
            for(int i = 0; i < size; ++i){
                temp[i] = data[i];
            }
            data = temp;
        }
    }

    /**
     * function to get capacity
     * @return capacity
     */
    public int getCapacity(){
        return data.length;
    }

    /**
     * method to add to an array at a certain index
     * @param index index where to add
     * @param element what is added
     */
    public void add(int index, E element){
        if(index < 0 || index > size){
            throw new IndexOutOfBoundsException(invalidInd);
        }
        if(size == data.length){
            expandCapacity(size + 1);
        }
        for(int i = size - 1; i >= index; --i){
            data[i + 1] = data[i];
        }
        data[index] = element;
        size++;
    }

    /**
     * method to append to the arraylist
     * @param element what is appended
     */
    public void append(E element){
        if(size == data.length){
            expandCapacity(size + 1);
        }
        data[size] = element;
        size++;
    }

    /**
     * method to get what is held at a certain index
     * @param index index which is retrieved
     * @return data held at the location
     */
    @SuppressWarnings("unchecked")
    public E get(int index){
        if(index < 0 || index >= data.length){
            throw new IndexOutOfBoundsException(invalidInd);
        }
        return (E) data[index];
    }

    /**
     * sets a certain index into the element given
     * @param index where it is setting
     * @param element what it is setting
     * @return what was overwritten
     */
    @SuppressWarnings("unchecked")
    public E set(int index, E element){
        if(index < 0 || index >= data.length){
            throw new IndexOutOfBoundsException(invalidInd);
        }
        Object temp = data[index];
        data[index] = element;
        return (E) temp;
    }

    /**
     * removes an element at an index
     * @param index where it is removing
     * @return the element that was removed
     */
    @SuppressWarnings("unchecked")
    public E remove(int index){
        if(index < 0 || index >= size){
            throw new IndexOutOfBoundsException(invalidInd);
        }
        E temp = (E) data[index];
        for(int i = index; i < size - 1; ++i){
            data[i] = data[i + 1];
        }
        size--;
        data[size] = null;
        return temp;
    }

    /**
     * gets the size of array
     * @return an int that has the size
     */
    public int size(){
        return size;
    }
}