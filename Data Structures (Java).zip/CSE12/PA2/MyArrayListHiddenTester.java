package PA2;

/*
 * Name: Edward Vu
 * PID: A18890254
 * Email: e3vu@ucsd.edu
 * References: N/A
 *
 * Contains the MyArrayListHiddenTester class which holds the tests to be used
 */

import static org.junit.Assert.*;

import java.rmi.server.ObjID;

import org.junit.*;

@SuppressWarnings("unused")
public class MyArrayListHiddenTester {
    // Do not change the method signatures!
    /**
     * This sets up the test fixture. JUnit invokes this method before
     * every testXXX method. The @Before tag tells JUnit to run this method
     * before each test 
     */
    @Before
    public void setUp() throws Exception {
        
    }

    // ----------------MyArrayList class----------------

    /**
     * Aims to test the constructor when the input argument
     * is not valid
     */
    @Test
    public void testConstructorInvalidArg(){
        boolean exception = false;
        try{
            MyArrayList<Integer> q = new MyArrayList<>(-1);
        }
        catch(IllegalArgumentException E){
            exception = true;
        }
        assertEquals(true, exception);
    }

    /**
     * Aims to test the constructor when the input argument is null
     */
    @Test
    public void testConstructorNullArg(){    
        MyArrayList<Integer> q = new MyArrayList<>(null);
        assertEquals(5, q.getCapacity());
        assertEquals(0, q.size());
    }

    /**
     * Aims to test the constructor when the input array has null elements
     */
    @Test
    public void testConstructorArrayWithNull(){
        Integer[] arr = {1, 2, null, 3, 4};
        MyArrayList<Integer> q = new MyArrayList<>(arr);
        assertEquals(5, q.size());
    }

    /**
     * Aims to test the append method when an element is added to a full list
     * Check reflection on size and capacity
     */
    @Test
    public void testAppendAtCapacity(){
        MyArrayList<Integer> arr = new MyArrayList<>(3);
        arr.append(1);
        arr.append(2);
        arr.append(3);
        arr.append(4);
        assertEquals("Expected size of 4",4,arr.size());
    }

    /**
     * Aims to test the append method when null is added to a full list
     * Check reflection on size and capacity
     */
    @Test
    public void testAppendNull(){
        MyArrayList<Integer> arr = new MyArrayList<>(3);
        arr.append(1);
        arr.append(2);
        arr.append(3);
        int old = arr.getCapacity();
        arr.append(null);
        assertEquals("Expected size of 4", 4, arr.size());
    }
    
    /**
     * Aims to test the add method when input index is out of bounds
     */
    @Test
    public void testAddOutOfBounds(){
        boolean exception = false;
        MyArrayList<Integer> arr = new MyArrayList<>(3);
        try{
            arr.add(4, 4);
        }
        catch(IndexOutOfBoundsException E){
            exception = true;
        }
        assertEquals(true, exception);
    }

    /**
     * Insert multiple (eg. 1000) elements sequentially beyond capacity -
     * Check reflection on size and capacity
     * Hint: for loop could come in handy
     */
    @Test
    public void testAddMultiple(){
        MyArrayList<Integer> arr = new MyArrayList<>(3);
        for(int i = 0; i < 6; ++i){
            arr.add(0, 10);
        }
        assertEquals(6, arr.size());
        assertEquals(6, arr.getCapacity());
    }

    /**
     * Aims to test the get method when input index is out of bound
     */
    @Test
    public void testGetOutOfBound(){
        boolean exception = false;
        MyArrayList<Integer> arr = new MyArrayList<>(3);
        try{
            arr.get(5);
        }
        catch(IndexOutOfBoundsException E){
            exception = true;
        }
        assertEquals(true, exception);
    }

    /**
     * Aims to test the set method when input index is out of bound
     */
    @Test
    public void testSetOutOfBound(){
        boolean exception = false;
        MyArrayList<Integer> arr = new MyArrayList<>(3);
        try{
            arr.set(5, 1);
        }
        catch(IndexOutOfBoundsException E){
            exception = true;
        }
        assertEquals(true, exception);
    }

    /**
     * Aims to test the remove method when removing multiple items from a list
     */
    @Test
    public void testRemoveMultiple(){
        MyArrayList<Integer> arr = new MyArrayList<>(3);
        arr.append(1);
        arr.append(2);
        arr.append(3);
        arr.remove(0);
        arr.remove(0);
        assertEquals(1, arr.size());
        assertEquals(3, arr.getCapacity());
    }

    /**
     * Aims to test the remove method when input index is out of bound
     */
    @Test
    public void testRemoveOutOfBound(){
        boolean exception = false;
        MyArrayList<Integer> arr = new MyArrayList<>(3);
        try{
            arr.remove(5);
        }
        catch(IndexOutOfBoundsException E){
            exception = true;
        }
        assertEquals(true, exception);
    }

    /**
     * Aims to test the expandCapacity method when 
     * requiredCapacity is strictly less than the current capacity
     */
    @Test
    public void testExpandCapacitySmaller(){
        boolean exception = false;
        MyArrayList<Integer> arr = new MyArrayList<>(3);
        try{
            arr.expandCapacity(2);
        }
        catch(IllegalArgumentException E){
            exception = true;
        }
        assertEquals(true, exception);
    }

    /**
     * Aims to test the expandCapacity method when 
     * requiredCapacity is greater than current capacity * 2 and default capacity
     */
    @Test
    public void testExpandCapacityLarge(){
        MyArrayList<Integer> arr = new MyArrayList<>(6);
        arr.expandCapacity(20);
        assertEquals(20, arr.getCapacity());
    }

    // ----------------MyAlgorithm class----------------

    /**
     * Aims to test the shiftToEnd method when elements alternate between those
     * that fall within the range and those that don't
     */
    @Test
    public void testShiftToEndAlternating(){
        MyArrayList<Integer> arr = new MyArrayList<>(6);
        MyArrayList<Integer> arr2 = new MyArrayList<>(6);
        arr.append(1);
        arr.append(10);
        arr.append(2);
        arr.append(11);
        arr.append(3);
        arr.append(12);
        arr2.append(1);
        arr2.append(2);
        arr2.append(3);
        arr2.append(10);
        arr2.append(11);
        arr2.append(12);
        MyAlgorithm.shiftToEnd(arr, 11, 1);
        for(int i = 0; i < arr.size(); ++i){
            assertEquals(arr2.get(i), arr.get(i));
        }
    }

    /**
     * Aims to test the shiftToEnd method when the input ArrayList is null
     */
    @Test
    public void testShiftToEndNull(){
        boolean exception = false;
        try{
            MyAlgorithm.shiftToEnd(null, 10, 1);
        }
        catch(NullPointerException E){
            exception = true;
        }
        assertEquals(true, exception);
    }

    /**
     * Aims to test the shiftToEnd method when the offset is negative
     */
    @Test
    public void testShiftToEndNegOffset(){
        boolean exception = false;
        MyArrayList<Integer> arr = new MyArrayList<>(3);
        try{
            MyAlgorithm.shiftToEnd(arr, 10, -1);
        }
        catch(IllegalArgumentException E){
            exception = true;
        }
        assertEquals(true, exception);
    }

}
