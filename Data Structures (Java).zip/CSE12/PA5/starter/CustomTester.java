/*
 * Name: Edward Vu
 * Email: e3vu@ucsd.edu
 * PID: A18890254
 * Sources Used: JDK 17 Doc
 *
 * IMPORTANT: Do not change the method headers. Your tests will be run against
 * good and bad implementations of Student/Course/Sanctuary. You will only
 * receive points if your test passes when run on a good implementation and
 * fails for the corresponding bad implementation.
 */

import static org.junit.Assert.*;
import org.junit.*;

/**
 * The custom tester for PA5, which covers some basic test cases.
 */
public class CustomTester {
    // Optional: add test variables here

    /**
	 * This sets up the test fixture. JUnit invokes this method before
	 * every testXXX method. The @Before tag tells JUnit to run this method
	 * before each test.
	 */
    @Before
    public void setup() {
        // Optional: add setup here
    }

    // ----------------MyHashMap class----------------

    /**
     * Test MyHashMap constructor with an invalid initial capacity
     */
    @Test
    public void testMyHashMapConstructorInvalidCapacity() {
        boolean exception = false;
        try{
            MyHashMap<Integer, Integer> hash = new MyHashMap<>(0);
        }
        catch(IllegalArgumentException E){
            exception = true;
        }
        assertEquals(true, exception);
    }

    /**
     * Test MyHashMap get with a null key
     */
    @Test
    public void testMyHashMapGetNullKey() {
        boolean exception = false;
        MyHashMap<Integer, Integer> hash = new MyHashMap<>();
        try{
            hash.get(null);
        }
        catch(NullPointerException E){
            exception = true;
        }
        assertEquals(true, exception);
    }

    /**
     * Test MyHashMap get with a key that does not exist in the hash table
     */
    @Test
    public void testMyHashMapGetKeyDoesNotExist() {
        MyHashMap<Integer, Integer> hash = new MyHashMap<>();
        hash.put(2, 1);
        hash.put(3, 4);
        Integer test = hash.get(5);
        assertEquals(null, test);
    }

    /**
     * Test MyHashMap put with a null key
     */
    @Test
    public void testMyHashMapPutNullKey() {
        boolean exception = false;
        MyHashMap<Integer, Integer> hash = new MyHashMap<>();
        hash.put(2, 1);
        hash.put(3, 4);
        try{
            hash.put(null, 5);
        }
        catch(NullPointerException E){
            exception = true;
        }
        assertEquals(true, exception);
    }

    /**
     * Test MyHashMap put with a key that already exists in the hash table
     */
    @Test
    public void testMyHashMapPutKeyAlreadyExists() {
        MyHashMap<Integer, Integer> hash = new MyHashMap<>();
        hash.put(2, 1);
        hash.put(3, 4);
        assertEquals((Integer) 1, hash.put(2, 5));
    }

    /**
     * Test MyHashMap remove with a null key
     */
    @Test
    public void testMyHashMapRemoveNullKey() {
        boolean exception = false;
        MyHashMap<Integer, Integer> hash = new MyHashMap<>();
        hash.put(2, 1);
        hash.put(3, 4);
        try{
            hash.remove(null);
        }
        catch(NullPointerException E){
            exception = true;
        }
        assertEquals(true, exception);
    }

    /**
     * Test MyHashMap remove with a key that does not exist in the hash table
     */
    @Test
    public void testMyHashMapRemoveKeyDoesNotExist() {
        MyHashMap<Integer, Integer> hash = new MyHashMap<>();
        hash.put(2, 1);
        hash.put(3, 4);
        assertEquals(null, hash.remove(1));
    }

    /**
     * Test MyHashMap getHash with a null key
     */
    @Test
    public void testMyHashMapGetHashNullKey() {
        boolean exception = false;
        MyHashMap<Integer, Integer> hash = new MyHashMap<>();
        hash.put(2, 1);
        hash.put(3, 4);
        try{
            hash.getHash(null, hash.getCapacity());
        }
        catch(NullPointerException E){
            exception = true;
        }
        assertEquals(true, exception);
    }

    // ----------------MyHashSet class----------------

    /**
     * Test MyHashMap put with a key that already exists in the hash table
     */
    @Test
    public void testMyHashSetAddAlreadyExists() {
        MyHashSet<Integer> hash = new MyHashSet<>();
        hash.add(5);
        hash.add(4);
        hash.add(3);
        assertEquals(false, hash.add(4));
    }

    /**
     * Test MyHashSet remove with a key that does not exist in the hash table
     */
    @Test
    public void testMyHashSetRemoveDoesNotExist() {
        MyHashSet<Integer> hash = new MyHashSet<>();
        hash.add(1);
        hash.add(2);
        hash.add(3);
        assertEquals(false, hash.remove(4));
    }
}