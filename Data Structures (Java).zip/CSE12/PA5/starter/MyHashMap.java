/*
 * Name: Edward Vu
 * Email: e3vu@ucsd.edu
 * PID: A18890254
 * Sources Used: 
 *
 * Contains the MyHashMap class which contains the methods needed for a hash
 * table
 */

/**
 * the class which contains the methods needed for the hash table
 */
public class MyHashMap<K,V> {
    private static final int DEFAULT_CAPACITY = 5;
    private static final double LOAD_FACTOR = 0.8;
    private static final int EXPAND_CAPACITY_RATIO = 2;
    private static final int HASH_CODE_MASK = 0x7fffffff;
    private static final String EXCEPTION = "Invalid";

    Node[] hashTable;
    int size;

    /**
     * the default constructor of the class
     */
    public MyHashMap() {
        size = 0;
        hashTable = new Node[DEFAULT_CAPACITY];
    }

    /**
     * constructor which takes in and initializes an initial capaciity
     * @param initialCapacity starting capacity for the hash table
     */
    public MyHashMap(int initialCapacity) {
        if(initialCapacity <= 0){
            throw new IllegalArgumentException(EXCEPTION);
        }
        size = 0;
        hashTable = new Node[initialCapacity];
    }

    /**
     * gets the value at a certain key
     * @param key key to be found
     * @return value at the key
     */
    public V get(K key) {
        if(key == null){
            throw new NullPointerException(EXCEPTION);
        }
        int index = getHash(key, hashTable.length);
        Node cur = hashTable[index];
        if(cur == null){
            return null;
        }
        while(cur != null){
            if(cur.getKey().equals(key) == true){
                return(V)  cur.getValue();
            }
            cur = cur.getNext();
        }
        return null;
    }

    /**
     * puts in a key and value into the hash table
     * @param key the key to be added in
     * @param value the value to be added in
     * @return value of what was in the key prior, null if it the key was new
     */
    public V put(K key, V value) {
        if(key == null || value == null){
            throw new NullPointerException(EXCEPTION);
        }
        if((hashTable.length * LOAD_FACTOR) <= size){
            expandCapacity();
        }
        int index = getHash(key, hashTable.length);
        Node cur = hashTable[index];
        if(cur == null){
            hashTable[index] = new Node<K,V>(key, value);
            size++;
            return null;
        }
        while(cur != null){
            if(cur.getKey().equals(key) == true){
                V temp = (V) cur.getValue();
                cur.setValue(value);
                return temp;
            }
            if(cur.getNext() == null){
                break;
            }
            cur = cur.getNext();
        }
        Node add = new Node<K,V>(key, value);
        cur.setNext(add);
        size++;
        return null;
    }

    /**
     * method to remove a key from the hash table
     * @param key key to be removed
     * @return whether or not the key was there and removed
     */
    public V remove(K key) {
        /* Add your implementation here */
        if(key == null){
            throw new NullPointerException(EXCEPTION);
        }
        int index = getHash(key, hashTable.length);
        Node cur = hashTable[index];
        if(cur == null){
            return null;
        }
        if(cur.getKey().equals(key) == true){
            V temp = (V) cur.getValue();
            hashTable[index] = cur.getNext();
            size --;
            return temp;
        }
        while(cur.getNext() != null){
            if(cur.getNext().getKey().equals(key) == true){
                V temp = (V) cur.getNext().getValue();
                cur.setNext(cur.getNext());
                size --;
                return temp;
            }
            cur = cur.getNext();
        }
        return null;
    }

    /**
     * method to get the size of the hashtable
     * @return size of hashtable
     */
    public int size() {
        /* Add your implementation here */
        return size;
    }

    /**
     * method to get the capacity of the hashtable
     * @return capacity of hashtable
     */
    public int getCapacity() {
        /* Add your implementation here */
        return hashTable.length;
    }

    /**
     * method to clear the hashtable
     */
    public void clear() {
        /* Add your implementation here */
        for(int i = 0; i < hashTable.length; ++i){
            while(hashTable[i] != null){
                remove((K)hashTable[i].getKey());
            }
        }
    }

    /**
     * method to check if the hashtable is empty
     * @return whether or not it is empty
     */
    public boolean isEmpty() {
        /* Add your implementation here */
        for(int i = 0; i < hashTable.length; ++i){
            if(hashTable[i] != null){
                return false;
            }
        }
        return true;
    }

    /**
     * method to double the capacity of the hashtable and also rehashes all 
     * keys in the table
     */
    public void expandCapacity() {
        /* Add your implementation here */
        Node[] temp = hashTable;
        size = 0;
        hashTable = new Node[temp.length * EXPAND_CAPACITY_RATIO];
        for(int i = 0; i < temp.length; ++i){
            Node cur = temp[i];
            while(cur != null){
                put((K)cur.getKey(), (V) cur.getValue());
                cur = cur.getNext();
            }
        }
    }

    /**
     * gets the hash of a key depending on capcity
     * @param key key to be hashed
     * @param capacity capacity of the table
     * @return hash of the key
     */
    public int getHash(K key, int capacity) {
        /* Add your implementation here */
        // TODO: Add checks for invalid inputs
        if(key == null){
            throw new NullPointerException(EXCEPTION);
        }
        if(capacity <= 0){
            throw new IllegalArgumentException(EXCEPTION);
        }

        // Hashing function is given here. DO NOT MODIFY THIS
        // You do not need to understand how it works
        return (key.hashCode() & HASH_CODE_MASK) % capacity;
    }

    /**
     * A Node class that holds (key, value) pairs and references to the next 
     * node in the linked list
     */
    protected class Node<K,V> {
        K key;
        V value;
        Node next;

        /**
         * Constructor to create a single node
         * @param key key to store in this node
         * @param value value to store in this node
         */
        public Node(K key, V value) {
            this.key = key;
            this.value = value;
            this.next = null;
        }

        /**
         * Accessor to get the next node in the list
         * @return the next node
         */
        public Node getNext() {
            return this.next;
        }

        /**
         * Set the next node in the list
         * @param n the new next node
         */
        public void setNext(Node n) {
            next = n;
        }

        /**
         * Accessor to get the node's key
         * @return this node's key
         */
        public K getKey() {
            return this.key;
        }

        /**
         * Set the node's key
         * @param key the new key
         */
        public void setKey(K key) {
            this.key = key;
        }

        /**
         * Accessor to get the node's value
         * @return this node's value
         */
        public V getValue() {
            return this.value;
        }

        /**
         * Set the node's value
         * @param value the new value
         */
        public void setValue(V value) {
            this.value = value;
        }

        /**
         * Check if this node is equal to another node
         * @param other the other node to check equality with
         * @return whether or not this node is equal to the other node
         */
        public boolean equals(Node<K, V> other) {
            return this.key.equals(other.key) && this.value.equals(other.value);
        }
    }
}
