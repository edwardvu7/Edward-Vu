/*
 * Name: Edward Vu
 * PID: A18890254
 * Email: e3vu@ucsd.edu
 * References: N/A
 *
 * Contains the MyPriorityQueue class which acts as a priorityqueue
 */

import java.util.Collection;

/**
 * the MyPriorityQueue class which acts as a priority queue
 */
public class MyPriorityQueue<E extends Comparable<E>> {
    protected MyMinHeap<E> heap;
    private static final String INVALID = "invalid";

    /**
     * the constructor of MyPriorityQueue with no arguments
     */
    public MyPriorityQueue(){
        heap = new MyMinHeap<>();
    }

    /**
     * constructor of MyPriorityQueue with an initial heap
     * @param collection initial heap
     */
    public MyPriorityQueue(Collection<? extends E> collection){
        if(collection == null || collection.contains(null)){
            throw new NullPointerException(INVALID);
        }
        heap = new MyMinHeap<>(collection);
    }

    /**
     * adds a new element to the priority queue
     * @param element element to be added
     */
    public void push(E element){
        if(element == null){
            throw new NullPointerException(INVALID);
        }
        heap.insert(element);
    }

    /**
     * gets the element with the highest priority
     * @return highest priority element
     */
    public E peek(){
        return heap.getMin();
    }

    /**
     * removes the element with the highest priority
     * @return element with highest priority
     */
    public E pop(){
        if(heap.size() == 0){
            return null;
        }
        return heap.remove();
    }

    /**
     * gets the length of the queue
     * @return length of queue
     */
    public int getLength(){
        return heap.size();
    }

    /**
     * clears the queue
     */
    public void clear(){
        heap.clear();
    }
}
