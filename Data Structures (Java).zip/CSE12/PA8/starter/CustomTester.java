/*
 * Name: Edward Vu
 * PID: A18890254
 * Email: e3vu@ucsd.edu
 * References: N/A
 *
 * Contains the CustomTester class to test the BST
 */

import org.junit.Before;
import org.junit.Test;

import java.beans.Transient;
import java.util.ArrayList;

import static org.junit.Assert.*;

/**
 * custom tester class that tests the BST
 */
public class CustomTester{

    MyBST<Integer, Integer> tree;

    /**
     * setup for before the tests
     */
    @Before
    public void setup() {
        MyBST.MyBSTNode<Integer, Integer> root =
                new MyBST.MyBSTNode<>(4, 1, null);
        MyBST.MyBSTNode<Integer, Integer> two =
                new MyBST.MyBSTNode<>(2, 1, root);
        MyBST.MyBSTNode<Integer, Integer> six =
                new MyBST.MyBSTNode<>(6, 1, root);
        MyBST.MyBSTNode<Integer, Integer> one =
                new MyBST.MyBSTNode<>(1, 2, two);
        MyBST.MyBSTNode<Integer, Integer> three =
                new MyBST.MyBSTNode<>(3, 30, two);
        MyBST.MyBSTNode<Integer, Integer> five =
                new MyBST.MyBSTNode<>(5, 50, six);

        this.tree = new MyBST<>();
        this.tree.root = root;
        root.setLeft(two);
        root.setRight(six);
        two.setLeft(one);
        two.setRight(three);
        six.setLeft(five);
        tree.size = 6;
    }

    /**
     * first test which checks the successor
     */
    @Test
    public void successorTest(){
        MyBST.MyBSTNode<Integer, Integer> node = tree.root.getRight();
        assertEquals(null, node.successor());
    }

    /**
     * test to check inserts
     */
    @Test
    public void insertTest(){
        Integer prev = tree.insert(3, 100);
        assertEquals(30, prev.intValue());
        assertEquals(100, tree.search(3).intValue());
        assertEquals(6, tree.size());
    }

    /**
     * test to check search
     */
    @Test
    public void searchTest(){
        assertEquals(1, tree.search(4).intValue());
    }

    /**
     * test to check remove
     */
    @Test
    public void removeTest(){
        tree.remove(2);
        assertEquals(null, tree.search(2));
        tree.remove(4);
        boolean rootcheck = false;
        if(tree.root.getKey().equals(5)){
            rootcheck = true;
        }
        assertEquals(true, rootcheck);
        assertEquals(4, tree.size());
        assertEquals(null, tree.remove(67));
    }

    /**
     * test to check rangeQuery
     */
    @Test
    public void rangeQueryTest(){
        ArrayList<MyBST.MyBSTNode<Integer, Integer>> res = tree.rangeQuery(10, 15);
        assertEquals(true, res.isEmpty());
    }

    /**
     * test to check copy
     */
    @Test
    public void copyTest(){
        MyBST<Integer, Integer> copied = tree.copy();
        assertNotSame(tree.root, copied.root);
        assertEquals(null, copied.root.getParent());
        assertNotSame(tree.root.getLeft(), copied.root.getLeft());
        assertEquals(tree.search(3), copied.search(3));
    }
}