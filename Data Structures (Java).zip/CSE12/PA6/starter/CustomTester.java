/*
 * Name: Edward Vu
 * PID: A18890254
 * Email: e3vu@ucsd.edu
 * References: N/A
 *
 * Contains the CustomTester class which acts as a tester
 */

import static org.junit.Assert.*;

import java.beans.Transient;

import org.junit.*;

/**
 * class containing tester used to test methods
 */
public class CustomTester {
    private MyDeque<Integer> test;
    /**
     * this sets up the tests before they begin 
     */
    @Before
    public void setUp() throws Exception{
        test = new MyDeque<Integer>(10);
        test.addFirst(0);
        test.addFirst(1);
        test.addFirst(2);
        test.addFirst(3);
        test.addFirst(4);
        test.addFirst(5);
        test.addFirst(6);
        test.addFirst(7);
        test.addFirst(8);
        test.addFirst(9);
    }

    /**
     * tests the constructor of the deque class
     */
    @Test
    public void constructorTest(){
        boolean exception = false;
        try{
            MyDeque<Integer> fail = new MyDeque<>(-3);
        }
        catch(IllegalArgumentException E){
            exception = true;
        }
        assertEquals(true, exception);
        assertEquals(10, test.size());
    }

    /**
     * tests the expandCapcity method
     */
    @Test
    public void expandTest(){
        boolean exception = false;
        test.expandCapacity();
        test.addLast(11);
        assertEquals(11, test.size());
        assertEquals(9, (int) test.removeFirst());
        assertEquals(8, (int) test.removeFirst());
    }

    /**
     * tests the addFirst method
     */
    @Test
    public void addFirstTest(){
        boolean exception = false;
        test.addFirst(12);
        try{
            test.addFirst(null);
        }
        catch(NullPointerException E){
            exception = true;
        }
        assertEquals(12, (int) test.removeFirst());
        assertEquals(true, exception);
    }

    /**
     * tests the addLast method
     */
    @Test
    public void addLastTest(){
        boolean exception = false;
        test.addLast(12);
        try{
            test.addLast(null);
        }
        catch(NullPointerException E){
            exception = true;
        }
        assertEquals(12, (int) test.removeLast());
        assertEquals(true, exception);
    }

    /**
     * tests the removeFirst method
     */
    @Test
    public void removeFirstTest(){
        assertEquals(9, (int) test.removeFirst());
        for(int i = 0; i < 9; ++i){
            test.removeFirst();
        }
        assertEquals(0, test.size());
        assertEquals(null, test.removeFirst());
    }

    /**
     * tests the removeLast method
     */
    @Test
    public void removeLastTest(){
        assertEquals(0, (int) test.removeLast());
        for(int i = 0; i < 9; ++i){
            test.removeLast();
        }
        assertEquals(0, test.size());
        assertEquals(null, test.removeLast());
    }

    /**
     * tests the stack class
     */
    @Test
    public void stackTest(){
        MyStack<Integer> taco = new MyStack<>(5);
        assertEquals(true, taco.empty());
        taco.push(0);
        taco.push(1);
        assertEquals(1, (int) taco.peek());
        assertEquals(2, taco.size());
        assertEquals(1, (int) taco.pop());
        assertEquals(0, (int) taco.peek());
    }

    /**
     * tests the queue class
     */
    @Test
    public void queueTest(){
        MyQueue<Integer> tuesday = new MyQueue<>(5);
        assertEquals(true, tuesday.empty());
        tuesday.enqueue(0);
        tuesday.enqueue(1);
        assertEquals(0, (int) tuesday.peek());
        assertEquals(0, (int) tuesday.dequeue());
        assertEquals(1, tuesday.size());
        assertEquals(1, (int) tuesday.peek());
    }
}
