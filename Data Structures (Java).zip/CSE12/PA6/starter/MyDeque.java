/*
 * Name: Edward Vu
 * PID: A18890254
 * Email: e3vu@ucsd.edu
 * References: N/A
 *
 * Contains the MyDequeue class which acts as a Deque
 */

/**
 * class which contains the methods needed for a deque
 */
public class MyDeque<E> implements DequeInterface<E>{
    Object[] data;
    int size;
    int rear;
    int front;
    private static final String INVALID = "INVALID";
    private static final int DEFAULTCAPACITY = 10;

    /**
     * constructor for the MyDeque class
     * @param initialCapacity initial capacity of the data array
     */
    public MyDeque(int initialCapacity){
        if(initialCapacity < 0){
            throw new IllegalArgumentException(INVALID);
        }
        data =  new Object[initialCapacity];
        front = 0;
        size = 0;
        rear = 0;
    }

    /**
     * Returns the number of elements in this DequeInterface.
     *
     * @return the number of elements in this DequeInterface
     */
    public int size(){
        return size;
    }

    /**
     * Doubles the capacity of this DequeInterface. If the capacity
     * is 0, set capacity to some default capacity. No elements in this
     * DequeInterface should change after the expansion.
     */
    public void expandCapacity(){
        if(data.length == 0){
            data = new Object[DEFAULTCAPACITY];
        }
        else{
            Object[] temp = new Object[data.length + data.length];
            for(int i = 0; i < size; ++i){
                temp[i] = data[(front + i) % data.length];
            }
            data = temp;
            front = 0;
            if(size == 0){
                rear = 0;
            }
            else{
                rear = size - 1;
            }
        }
    }

    /**
     * Adds the specified element to the front of this DequeInterface. If this
     * DequeInterface is at capacity, expandCapacity is called to double the
     * size of this container.
     *
     * @param element the element to add to the front of the array
     * @throws NullPointerException if the specified element is null.
     */
    public void addFirst(E element){
        if(element == null){
            throw new NullPointerException(INVALID);
        }
        if(size == data.length){
            expandCapacity();
        }
        if(size == 0){
            data[front] = element;
        }
        else if(front == 0){
            data[data.length - 1] = element;
            front = data.length - 1;
        }
        else{
            data[front - 1] = element;
            front --;
        }
        size++;
    }

    /**
     * Adds the specified element to the back of this DequeInterface. If the
     * DequeInterface is at capacity, expandCapacity is called to double the
     * size of this container.
     *
     * @param element the element to add to the back of the array
     * @throws NullPointerException if the specified element is null.
     */
    public void addLast(E element){
        if(element == null){
            throw new NullPointerException(INVALID);
        }
        if(size == data.length){
            expandCapacity();
        }
        if(size == 0){
            data[rear] = element;
        }
        else if(rear == data.length - 1){
            data[0] = element;
            rear = 0;
        }
        else{
            data[rear + 1] = element;
            rear ++; 
        }
        size++;
    }


    /**
     * Removes the element at the front of this DequeInterface, and returns the
     * element removed, or null if there was no such element.
     *
     * @return the element removed, or null if there's none.
     */
    public E removeFirst(){
        if(size == 0){
            return null;
        }
        E temp = (E) data[front];
        data[front] = null;
        front++;
        if(front == data.length){
            front = 0;
        }
        size --;
        return temp;
    }

    /**
     * Removes the element at the back of this DequeInterface, and returns the
     * element removed, or null if there was no such element.
     *
     * @return the element removed, or null if there's none.
     */
    public E removeLast(){
        if(size == 0){
            return null;
        }
        E temp = (E) data[rear];
        data[rear] = null;
        rear--;
        if(rear < 0){
            rear = data.length - 1;
        }
        size --;
        return temp;
    }

    /**
     * Returns the element at the front of this DequeInterface,
     * or null if there was no such element.
     *
     * @return the element at the front, or null if there's none.
     */
    public E peekFirst(){
        if(size == 0){
            return null;
        }
        return (E) data[front];
    }

    /**
     * Returns the element at the back of this DequeInterface,
     * or null if there was no such element.
     *
     * @return the element at the back, or null if there's none.
     */
    public E peekLast(){
        if(size == 0){
            return null;
        }
        return (E) data[rear];
    }
    
}
