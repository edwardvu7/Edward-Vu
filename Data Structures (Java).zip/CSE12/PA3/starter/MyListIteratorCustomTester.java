/*
 * Name: Edward Vu
 * PID: A18890254
 * Email: e3vu@ucsd.edu
 * References: N/A
 *
 * Contains the MyAlgorithm class which holds the algorithm to be tested
 */

import static org.junit.Assert.*;
import org.junit.*;
import java.util.NoSuchElementException;

public class MyListIteratorCustomTester {

    /**
     * This sets up the test fixture. JUnit invokes this method before
     * every testXXX method. The @Before tag tells JUnit to run this method
     * before each test.
     */
    @Before
    public void setUp() throws Exception {

    }

    /**
     * Aims to test the next() method when iterator is at end of the list 
     */
    @Test
    public void testNextEnd() {
        MyLinkedList<Integer> list = new MyLinkedList<>();
        MyLinkedList.MyListIterator test = list.new MyListIterator();
        boolean exception = false;
        try{
            test.next();
        }
        catch(NoSuchElementException E){
            exception = true;
        }
        assertEquals(true, exception);
    }

    /**
     * Aims to test the previous() method when iterator is at the start of the 
     * list 
     */
    @Test
    public void testPreviousStart() {
        MyLinkedList<Integer> list = new MyLinkedList<>();
        MyLinkedList.MyListIterator test = list.new MyListIterator();
        boolean exception = false;
        try{
            test.previous();
        }
        catch(NoSuchElementException E){
            exception = true;
        }
        assertEquals(true, exception);
    }

    /**
     * Aims to test the add(E e) method when an invalid element is added
     */
    @Test
    public void testAddInvalid() {
        MyLinkedList<Integer> list = new MyLinkedList<>();
        MyLinkedList.MyListIterator test = list.new MyListIterator();
        boolean exception = false;
        try{
            test.add(null);
        }
        catch(NullPointerException E){
            exception = true;
        }
        assertEquals(true, exception);
    }

    /**
     * Aims to test the set(E e) method when canRemoveOrSet is false
     */
    @Test
    public void testCantSet() {
        MyLinkedList<Integer> list = new MyLinkedList<>();
        MyLinkedList.MyListIterator test = list.new MyListIterator();
        boolean exception = false;
        try{
            test.set(10);
        }
        catch(IllegalStateException E){
            exception = true;
        }
        assertEquals(true, exception);
    }

    /**
     * Aims to test the remove() method when canRemoveOrSet is false
     */
    @Test
    public void testCantRemove() {
        MyLinkedList<Integer> list = new MyLinkedList<>();
        MyLinkedList.MyListIterator test = list.new MyListIterator();
        boolean exception = false;
        try{
            test.remove();
        }
        catch(IllegalStateException E){
            exception = true;
        }
        assertEquals(true, exception);
    }

    /**
     * Aims to tests the hasNext() method at the end of a list
     */
    @Test
    public void testHasNextEnd() {
        MyLinkedList<Integer> list = new MyLinkedList<>();
        MyLinkedList.MyListIterator test = list.new MyListIterator();
        boolean has = test.hasNext();
        assertEquals(false, has);
    }

    /**
     * Aims to test the hasPrevious() method at the start of a list
     */
    @Test
    public void testHasPreviousStart() {
        MyLinkedList<Integer> list = new MyLinkedList<>();
        MyLinkedList.MyListIterator test = list.new MyListIterator();
        boolean has = test.hasPrevious();
        assertEquals(false, has);
    }

    /**
     * Aims to test the previousIndex() method at the start of a list
     */
    @Test
    public void testPreviousIndexStart() {
        MyLinkedList<Integer> list = new MyLinkedList<>();
        MyLinkedList.MyListIterator test = list.new MyListIterator();
        int start = test.previousIndex();
        assertEquals(-1, start);
    }

    /**
     * Aims to test the nextIndex() method at the end of a list
     */
    @Test
    public void testNextIndexEnd() {
        MyLinkedList<Integer> list = new MyLinkedList<>();
        MyLinkedList.MyListIterator test = list.new MyListIterator();
        int end = test.nextIndex();
        assertEquals(0, end);
    }
}
