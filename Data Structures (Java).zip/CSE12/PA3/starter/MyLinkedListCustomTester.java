/*
 * Name: Edward Vu
 * PID: A18890254
 * Email: e3vu@ucsd.edu
 * References: N/A
 *
 * Contains the MyArrayList class which acts as an ArrayList
 */


/**
 * class containing methods used in an Arraylist
 */

import static org.junit.Assert.*;

import org.junit.*;

public class MyLinkedListCustomTester {

	// Optional: add test variables here

	/**
	 * This sets up the test fixture. JUnit invokes this method before
	 * every testXXX method. The @Before tag tells JUnit to run this method
	 * before each test.
	 */
	@Before
	public void setUp() throws Exception {
		// Optional: add setup here
	}

	/**
	 * Aims to test the add(E data) method with a valid argument.
	 */
	@Test
	public void testCustomAdd() {
		boolean success = false;
		boolean nul = false;
		boolean ind = false;
		MyLinkedList<Integer> test = new MyLinkedList<>();
		success = test.add(10);
		test.add(11);
		assertEquals(10, (int) test.get(0));
		assertEquals(11, (int) test.get(1));
		assertEquals(true, success);
	}

	/**
	 * Aims to test the add(int index, E data) method.
	 * Add a valid argument to the beginning of MyLinkedList.
	 */
	@Test
	public void testCustomAddIdxToStart() {
		MyLinkedList<Integer> test = new MyLinkedList<>();
		test.add(0);
		test.add(1);
		test.add(3);
		test.add(5);
		test.add(0, 2);
		test.add(0, 4);
		assertEquals(2, (int) test.get(1));
		assertEquals(4, (int) test.get(0));
	}

	/**
	 * Aims to test the add(int index, E data) method.
	 * Add a valid argument to the middle of MyLinkedList.
	 */
	@Test
	public void testCustomAddIdxToMiddle() {
		MyLinkedList<Integer> test = new MyLinkedList<>();
		test.add(0);
		test.add(1);
		test.add(3);
		test.add(4);
		test.add(test.size()/2, 2);
		assertEquals(5, test.size());
		assertEquals(0, (int) test.get(0));
		assertEquals(1, (int) test.get(1));
		assertEquals(2, (int) test.get(2));
		assertEquals(3, (int) test.get(3));
		assertEquals(4, (int)test.get(4));
	}

	/**
	 * Aims to test the remove(int index) method. Remove from an empty list.
	 */
	@Test
	public void testCustomRemoveFromEmpty() {
		boolean exception = false;
		try{
			MyLinkedList<Integer> test = new MyLinkedList<>();
			test.remove(1);
		}
		catch(IndexOutOfBoundsException E){
			exception = true;
		}
		assertEquals(true, exception);
	}

	/**
	 * Aims to test the remove(int index) method.
	 * Remove a valid argument from the middle of MyLinkedList.
	 */
	@Test
	public void testCustomRemoveFromMiddle() {
		MyLinkedList<Integer> test = new MyLinkedList<>();			
		test.add(0);
		test.add(1);
		test.add(2);
		test.add(3);
		test.add(4);
		int size1 = test.size();
		Integer data = test.remove(size1/2);
		assertEquals(2, (int) data);
		assertEquals(3, (int) test.getNth(1).getNext().getElement());
		assertEquals(1, (int) test.getNth(2).getPrev().getElement());
		assertEquals(size1 - 1, test.size());
		assertEquals(0, (int) test.get(0));
		assertEquals(1, (int) test.get(1));
		assertEquals(3, (int) test.get(2));
		assertEquals(4, (int) test.get(3));
	}

	/**
	 * Aims to test the set(int index, E data) method.
	 * Set an out-of-bounds index with a valid data argument.
	 */
	@Test
	public void testCustomSetIdxOutOfBounds() {
		boolean exception = false;
		try{
			MyLinkedList<Integer> test = new MyLinkedList<>();
			test.add(0);
			test.set(1, 1);
		}
		catch(IndexOutOfBoundsException E){
			exception = true;
		}
		assertEquals(true, exception);
	}

	/**
	 * Aims to test the mergeLists(MyLinkedList<E> left, MyLinkedList<E> right)
	 * method.
	 * Merge lists when one is longer than the other. 
	 */
	@Test
	public void testCustomMergeUnequalSize() {
		MyLinkedList<Integer> left = new MyLinkedList<>();
		MyLinkedList<Integer> right = new MyLinkedList<>();
		left.add(0);
		left.add(1);
		right.add(2);
		right.add(3);
		right.add(4);
		MyLinkedList<Integer> test = MyAlgorithm.mergeLists(left, right);
		assertEquals(0, (int) test.get(0));
		assertEquals(1, (int) test.get(1));
		assertEquals(2,(int) test.get(2));
		assertEquals(3, (int) test.get(3));
		assertEquals(4, (int) test.get(4));
	}

	/**
	 * Aims to test the mergeLists(MyLinkedList<E> left, MyLinkedList<E> right)
	 * method.
	 * Merge lists when both lists share a value.
	 */
	@Test
	public void testCustomMergeDuplicates() {
		MyLinkedList<Integer> left = new MyLinkedList<>();
		MyLinkedList<Integer> right = new MyLinkedList<>();
		left.add(0);
		left.add(1);
		left.add(2);
		left.add(3);
		right.add(2);
		right.add(3);
		right.add(4);
		MyLinkedList<Integer> test = MyAlgorithm.mergeLists(left, right);
		assertEquals(0, (int) test.get(0));
		assertEquals(1, (int) test.get(1));
		assertEquals(2,(int) test.get(2));
		assertEquals(2, (int) test.get(3));
		assertEquals(3, (int) test.get(4));
		assertEquals(4, (int) test.get(6));
	}

}
