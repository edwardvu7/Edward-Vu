/*
 * Name: Edward Vu
 *
 * Contains the MyArrayList class which acts as an ArrayList
 */



import java.util.AbstractList;
import java.util.ListIterator;
import java.util.NoSuchElementException;
import java.util.Iterator;

/**
 * class containing methods used in an Arraylist
 */
public class MyLinkedList<E> extends AbstractList<E> {

    private static final String INVALID = "Invalid index";
    int size;
    Node head;
    Node tail;

    /**
     * class to implement ListIterator
     * @return new listIterator
     */
    public ListIterator<E> listIterator() {
        return new MyListIterator();
    }

    /**
     * class to implement listIterator
     * @return new listIterator
     */
    public Iterator<E> iterator() {
        return new MyListIterator();
    }

    /**
     * A Node class that holds data and references to previous and next Nodes.
     */
    protected class Node {
        E data;
        Node next;
        Node prev;

        /** 
         * Constructor to create singleton Node 
         * @param element Element to add, can be null	
         */
        public Node(E element) {
            // Initialize the instance variables
            this.data = element;
            this.next = null;
            this.prev = null;
        }

        /** 
         * Set the parameter prev as the previous node
         * @param prev new previous node
         */
        public void setPrev(Node prev) {
            this.prev = prev;		
        }

        /** 
         * Set the parameter next as the next node
         * @param next new next node
         */
        public void setNext(Node next) {
            this.next = next;
        }

        /** 
         * Set the parameter element as the node's data
         * @param element new element 
         */
        public void setElement(E element) {
            this.data = element;
        }

        /** 
         * Accessor to get the next Node in the list 
         * @return the next node
         */
        public Node getNext() {
            return this.next;
        }
        /** 
         * Accessor to get the prev Node in the list
         * @return the previous node  
         */
        public Node getPrev() {
            return this.prev;
        } 
        /** 
         * Accessor to get the Nodes Element 
         * @return this node's data
         */
        public E getElement() {
            return this.data;
        } 
    }

    //  Implementation of the MyLinkedList Class

    /**
     * Constructor which initializes the list and all variables
     */
    public MyLinkedList() {
        /* Add your implementation here */
        size = 0;
        head = new Node(null);
        tail = new Node(null);
        head.setNext(tail);
        tail.setPrev(head);
    }

    /**
     * this function returns the size of the list
     * @return returns the size of the list
     */
    @Override
    public int size() {
        /* Add your implementation here */
        return size;
    }

    /**
     * this function gets the element at a certain index of the list
     * @param index the index of which to get the element from
     * @return the element held at the index
     */
    @Override
    public E get(int index) {
        /* Add your implementation here */
        if(index < 0 || index >= size){
            throw new IndexOutOfBoundsException(INVALID);
        }
        Node cur = head.getNext();
        for(int i = 0; i < index; ++i){
            cur = cur.getNext();
        }
        return (E) cur.getElement();
    }

    /**
     * adds to the list at a certain index
     * @param index where to add
     * @param data data of the node that will be added
     */
    @Override
    public void add(int index, E data) {
        /* Add your implementation here */
        if(data == null){
            throw new NullPointerException(INVALID);
        }
        if(index < 0 || index > size){
            throw new IndexOutOfBoundsException(INVALID);
        }
        Node toAdd = new Node(data);
        Node cur = head.getNext();
        for(int i = 0; i < index; ++i){
            cur = cur.getNext();
        }
        toAdd.setNext(cur);
        toAdd.setPrev(cur.getPrev());
        cur.getPrev().setNext(toAdd);
        cur.setPrev(toAdd);
        size++;
    }

    /**
     * adds to the end of the list using the data given
     * @param data the data of the node to be added to list
     * @return true since it is added
     */
    @Override
    public boolean add(E data) {
        /* Add your implementation here */
        if(data == null){
            throw new NullPointerException(INVALID);
        }
        Node toAdd = new Node(data);
        toAdd.setPrev(tail.getPrev());
        tail.getPrev().setNext(toAdd);
        tail.setPrev(toAdd);
        toAdd.setNext(tail);
        size++;
        return true;
    }

    /**
     * sets the data of the node at the index to the data given
     * @param index the node which will be getting the data
     * @param data the new data of the node at index
     * @return the old data of the node
     */
    @Override
    public E set(int index, E data) {
        /* Add your implementation here */
        if(data == null){
            throw new NullPointerException(INVALID);
        }
        if(index < 0 || index >= size){
            throw new IndexOutOfBoundsException(INVALID);
        }
        Node cur = head.getNext();
        for(int i = 0; i < index; ++i){
            cur = cur.getNext();
        }
        Node curData = new Node(cur.getElement());
        cur.setElement(data);
        return (E) curData.getElement(); 
    }

    /**
     * removes a node at a certain index
     * @param index the node to be removed
     * @return the data of the removed node
     */
    @Override
    public E remove(int index) {
        /* Add your implementation here */
        if(index < 0 || index >= size){
            throw new IndexOutOfBoundsException(INVALID);
        }
        Node cur = head.getNext();
        for(int i = 0; i < index; ++i){
            cur = cur.getNext();
        }
        cur.getPrev().setNext(cur.getNext());
        cur.getNext().setPrev(cur.getPrev());
        size--;
        return (E) cur.getElement(); 
    }

    /**
     * clears the list besides the sentinel nodes
     */
    @Override
    public void clear() {
        /* Add your implementation here */
        size = 0;
        head.setNext(tail);
        tail.setPrev(head);
    }

    /**
     * checks if the list is empty
     * @return whether the list is empty
     */
    @Override
    public boolean isEmpty() {
        /* Add your implementation here */
        if(size == 0){
            return true;
        } 
        else{
            return false;
        }
    }

    /**
     * gets the node at the index
     * @param index the node to get
     * @return node at the index
     */
    protected Node getNth(int index) {
        /* Add your implementation here */
        if(index < 0 || index >= size){
            throw new IndexOutOfBoundsException(INVALID);
        }
        Node cur = head.getNext();
        for(int i = 0; i < index; ++i){
            cur = cur.getNext();
        }
        return (Node) cur;  
    }

    /**
     * a MyListIterator class which allows for iteration through linkedlists
     */
    protected class MyListIterator implements ListIterator<E>{
        Node left;
        Node right;
        int idx;
        boolean forward;
        boolean canRemoveOrSet;

        /**
         * constructor to initialize iterator variables
         */
        public MyListIterator(){
            forward = true;
            canRemoveOrSet = false;
            left = head;
            right = head.getNext();
            int idx = 0;
        }

        /**
         * function to check if there is something next
         * @return whether or not there is something next 
         */
        public boolean hasNext(){
            if(left.getNext() != tail){
                return true;
            }
            return false;
        }

        /**
         * returns the next node and moves to the next ones
         * @return returns the node
         */
        public E next(){
            if(hasNext() == false){
                throw new NoSuchElementException(INVALID);
            }
            canRemoveOrSet = true;
            forward = true;
            left = left.getNext();
            right = right.getNext();
            idx++;
            return left.getElement();
        }

        /**
         * checks if there is a previous node
         * @return whether there is a previous node
         */
        public boolean hasPrevious(){
            if(right.getPrev() != head){
                return true;
            }
            return false;
        }

        /**
         * moves the iterator back one index and gets the element
         * @return the element of the node
         */
        public E previous(){
            if(hasPrevious() == false){
                throw new NoSuchElementException(INVALID);
            }
            canRemoveOrSet = true;
            forward = false;
            left = left.getPrev();
            right = right.getPrev();
            idx--;
            return right.getElement();
        }

        /**
         * checks the next index
         * @return index of next node
         */
        public int nextIndex(){
            return idx;
        }

        /**
         * checks the index of the previous node
         * @return index of previous node
         */
        public int previousIndex(){
            if(hasPrevious() == true){
                return idx - 1;
            }
            else{
                return -1;
            }
        }

        /**
         * adds a node to the linkedlist
         * @param element the data to be added in the node
         */
        public void add(E element){
            if(element == null){
                throw new NullPointerException(INVALID);
            }
            size++;
            idx++;
            canRemoveOrSet = false;
            Node add = new Node(element);
            add.setNext(right);
            add.setPrev(left);
            left = add;
            left.getPrev().setNext(add);
            right.setPrev(add);
        }

        /**
         * sets the data at current node to element
         * @param element the data to be set
         */
        public void set(E element){
            if(element == null){
                throw new NullPointerException(INVALID);
            }
            if(canRemoveOrSet == false){
                throw new IllegalStateException(INVALID);
            }
            if(forward == true){
                left.setElement(element);
            }
            else{
                right.setElement(element);
            }
            canRemoveOrSet = false;
        }

        /**
         * removes the current node
         */
        public void remove(){
            if(canRemoveOrSet == false){
                throw new IllegalStateException(INVALID);
            }
            if(forward ==  true){
                left.getPrev().setNext(right);
                right.setPrev(left.getPrev());
                left = left.getPrev();
                idx--;
            }
            else{
                right.getNext().setPrev(left);
                left.setNext(right.getNext());
                right = right.getNext();
            }
            size--;
            canRemoveOrSet = false;
        }
    }
    
}
